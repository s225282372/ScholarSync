package com.example.learningmanagementsystemproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "LMS.db";
    public static final int DATABASE_VERSION = 1;

    // User table
    public static final String TABLE_USERS = "users";
    public static final String COL_USER_ID = "id";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD = "password";
    public static final String COL_ROLE = "role"; // admin, instructor, student

    // Student table
    public static final String TABLE_STUDENTS = "students";
    public static final String COL_STUDENT_ID = "studentID";
    public static final String COL_STUDENT_NAME = "studentName";
    public static final String COL_STUDENT_SURNAME = "studentSurname";
    public static final String COL_STUDENT_DOB = "dob";

    // Module table
    public static final String TABLE_MODULES = "modules";
    public static final String COL_MODULE_ID = "moduleID";
    public static final String COL_MODULE_NAME = "moduleName";
    public static final String COL_MODULE_DURATION = "duration";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create users table
        db.execSQL("CREATE TABLE " + TABLE_USERS + " (" +
                COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USERNAME + " TEXT UNIQUE, " +
                COL_PASSWORD + " TEXT, " +
                COL_ROLE + " TEXT)");

        // Create students table
        db.execSQL("CREATE TABLE " + TABLE_STUDENTS + " (" +
                COL_STUDENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_STUDENT_NAME + " TEXT, " +
                COL_STUDENT_SURNAME + " TEXT, " +
                COL_STUDENT_DOB + " TEXT)");

        // Create modules table
        db.execSQL("CREATE TABLE " + TABLE_MODULES + " (" +
                COL_MODULE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_MODULE_NAME + " TEXT, " +
                COL_MODULE_DURATION + " TEXT)");

        // Insert default users for testing
        insertDefaultUsers(db);
    }

    private void insertDefaultUsers(SQLiteDatabase db) {
        insertUser(db, "admin1", "adminpass", "admin");
        insertUser(db, "student1", "studpass", "student");
        insertUser(db, "instructor1", "instructpass", "instructor");
    }

    private void insertUser(SQLiteDatabase db, String username, String password, String role) {
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, password);
        values.put(COL_ROLE, role);
        db.insert(TABLE_USERS, null, values);
    }

    public boolean checkUserRole(String username, String password, String role) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS +
                " WHERE " + COL_USERNAME + " = ? AND " +
                COL_PASSWORD + " = ? AND " +
                COL_ROLE + " = ?", new String[]{username, password, role});
        boolean exists = (cursor.getCount() > 0);
        cursor.close();
        return exists;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop and recreate tables if needed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_STUDENTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_MODULES);
        onCreate(db);
    }
}
