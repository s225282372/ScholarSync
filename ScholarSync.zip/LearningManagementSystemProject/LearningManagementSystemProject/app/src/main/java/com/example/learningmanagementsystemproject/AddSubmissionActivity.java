package com.example.learningmanagementsystemproject;

import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class AddSubmissionActivity extends AppCompatActivity {

    LinearLayout fileListContainer;
    Button addFileButton, removeFileButton, submitButton;

    // Store file names as strings (simulate files)
    ArrayList<String> fileNames = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_submission);

        fileListContainer = findViewById(R.id.file_list_container);
        addFileButton = findViewById(R.id.button_add_file);
        removeFileButton = findViewById(R.id.button_remove_file);
        submitButton = findViewById(R.id.button_submit);

        updateFileListDisplay();

        addFileButton.setOnClickListener(v -> {
            // Simulate adding a new file with a simple name
            String newFileName = "File_" + (fileNames.size() + 1) + ".txt";
            fileNames.add(newFileName);
            updateFileListDisplay();
        });

        removeFileButton.setOnClickListener(v -> {
            if (!fileNames.isEmpty()) {
                // Remove last file
                fileNames.remove(fileNames.size() - 1);
                updateFileListDisplay();
            } else {
                Toast.makeText(AddSubmissionActivity.this, "No files to remove", Toast.LENGTH_SHORT).show();
            }
        });

        submitButton.setOnClickListener(v -> {
            if (fileNames.isEmpty()) {
                Toast.makeText(AddSubmissionActivity.this, "Please add at least one file before submitting", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(AddSubmissionActivity.this, "Submission received with " + fileNames.size() + " files!", Toast.LENGTH_LONG).show();
                // TODO: Add saving/upload logic here if needed

                finish(); // Close this activity
            }
        });
    }

    private void updateFileListDisplay() {
        fileListContainer.removeAllViews();

        if (fileNames.isEmpty()) {
            // Show placeholder text
            TextView placeholder = new TextView(this);
            placeholder.setText("No files added");
            placeholder.setTextColor(getResources().getColor(android.R.color.darker_gray));
            placeholder.setTextSize(16);
            placeholder.setGravity(Gravity.CENTER);
            placeholder.setPadding(0, 20, 0, 20);

            fileListContainer.addView(placeholder);
        } else {
            // Add TextView for each file name
            for (String fileName : fileNames) {
                TextView fileTextView = new TextView(this);
                fileTextView.setText(fileName);
                fileTextView.setTextColor(getResources().getColor(android.R.color.black));
                fileTextView.setTextSize(16);
                fileTextView.setPadding(8, 8, 8, 8);
                fileListContainer.addView(fileTextView);
            }
        }
    }
}
