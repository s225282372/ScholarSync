package com.example.learningmanagementsystemproject;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class TimelineDetailActivity extends AppCompatActivity {

    TextView titleTextView, dueDateTextView, courseNameTextView;
    Button addSubmissionButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timeline_detail);

        // Initialize views
        titleTextView = findViewById(R.id.timeline_detail_title);
        dueDateTextView = findViewById(R.id.timeline_detail_due_date);
        courseNameTextView = findViewById(R.id.timeline_detail_course_name);
        addSubmissionButton = findViewById(R.id.add_submission_button);

        // Get data from intent extras
        String title = getIntent().getStringExtra("TIMELINE_TITLE");
        String dueDate = getIntent().getStringExtra("TIMELINE_DUE_DATE");
        String courseName = getIntent().getStringExtra("TIMELINE_COURSE_NAME");

        // Set data to TextViews
        if (title != null) {
            titleTextView.setText(title);
        }
        if (dueDate != null) {
            dueDateTextView.setText("Due: " + dueDate);
        }
        if (courseName != null) {
            courseNameTextView.setText(courseName);
        }

        // Set button click to open AddSubmissionActivity
        addSubmissionButton.setOnClickListener(v -> {
            Intent intent = new Intent(TimelineDetailActivity.this, AddSubmissionActivity.class);
            startActivity(intent);
        });
    }
}
