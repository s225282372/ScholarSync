package com.example.learningmanagementsystemproject;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

public class StudentDashboardActivity extends AppCompatActivity {

    ImageButton logoutBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_navigation);

        // Course cards
        LinearLayout imobCard = findViewById(R.id.imob_card);
        LinearLayout webCard = findViewById(R.id.web_card);
        LinearLayout dataCard = findViewById(R.id.data_card);

        imobCard.setOnClickListener(v -> openCourse("IMOB301", "Mobile Development"));
        webCard.setOnClickListener(v -> openCourse("WEB202", "Web Design Basics"));
        dataCard.setOnClickListener(v -> openCourse("DATA150", "Data Structures"));

        // Timeline items - add LinearLayout IDs in your XML accordingly
        LinearLayout timelineItem1 = findViewById(R.id.timeline_item_1);
        LinearLayout timelineItem2 = findViewById(R.id.timeline_item_2);
        LinearLayout timelineItem3 = findViewById(R.id.timeline_item_3);

        timelineItem1.setOnClickListener(v -> openTimelineDetail(
                "IMOB301 Assignment 1",
                "29 May 2025",
                "Mobile Development"
        ));

        timelineItem2.setOnClickListener(v -> openTimelineDetail(
                "WEB202 Quiz 2",
                "30 May 2025",
                "Web Design Basics"
        ));

        timelineItem3.setOnClickListener(v -> openTimelineDetail(
                "DATA150 Project",
                "31 May 2025",
                "Data Structures"
        ));

        // Logout button
        logoutBtn = findViewById(R.id.btn_logout);
        logoutBtn.setOnClickListener(v -> {
            Intent intent = new Intent(StudentDashboardActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }

    // Navigate to CourseDetailActivity
    private void openCourse(String courseCode, String courseName) {
        Intent intent = new Intent(StudentDashboardActivity.this, CourseDetailActivity.class);
        intent.putExtra("COURSE_CODE", courseCode);
        intent.putExtra("COURSE_NAME", courseName);
        startActivity(intent);
    }

    // Navigate to TimelineDetailActivity with timeline item details
    private void openTimelineDetail(String title, String dueDate, String courseName) {
        Intent intent = new Intent(StudentDashboardActivity.this, TimelineDetailActivity.class);
        intent.putExtra("TIMELINE_TITLE", title);
        intent.putExtra("TIMELINE_DUE_DATE", dueDate);
        intent.putExtra("TIMELINE_COURSE_NAME", courseName);
        startActivity(intent);
    }
}
