package com.example.learningmanagementsystemproject;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ViewTaskActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_task);

        // Task 1
        TextView taskTitle1 = findViewById(R.id.taskTitle1);
        TextView taskDescription1 = findViewById(R.id.taskDescription1);
        taskTitle1.setText("Task 1: Math Homework");
        taskDescription1.setText("Complete exercises 1 to 10 on page 23.");

        // Task 2
        TextView taskTitle2 = findViewById(R.id.taskTitle2);
        TextView taskDescription2 = findViewById(R.id.taskDescription2);
        taskTitle2.setText("Task 2: Science Project");
        taskDescription2.setText("Build a model volcano.");

        // Task 3
        TextView taskTitle3 = findViewById(R.id.taskTitle3);
        TextView taskDescription3 = findViewById(R.id.taskDescription3);
        taskTitle3.setText("Task 3: English Essay");
        taskDescription3.setText("Write a 500-word essay on your favorite book.");

        // Task 4
        TextView taskTitle4 = findViewById(R.id.taskTitle4);
        TextView taskDescription4 = findViewById(R.id.taskDescription4);
        taskTitle4.setText("Task 4: History Presentation");
        taskDescription4.setText("Prepare a 10-minute presentation on World War II.");

        // Task 5
        TextView taskTitle5 = findViewById(R.id.taskTitle5);
        TextView taskDescription5 = findViewById(R.id.taskDescription5);
        taskTitle5.setText("Task 5: Art Project");
        taskDescription5.setText("Create a landscape painting using watercolors.");

        // Task 6
        TextView taskTitle6 = findViewById(R.id.taskTitle6);
        TextView taskDescription6 = findViewById(R.id.taskDescription6);
        taskTitle6.setText("Task 6: Computer Science");
        taskDescription6.setText("Write a simple Android app that displays 'Hello World'.");

        // Task 7
        TextView taskTitle7 = findViewById(R.id.taskTitle7);
        TextView taskDescription7 = findViewById(R.id.taskDescription7);
        taskTitle7.setText("Task 7: Physical Education");
        taskDescription7.setText("Complete a 5km run and record your time.");

        // Task 8
        TextView taskTitle8 = findViewById(R.id.taskTitle8);
        TextView taskDescription8 = findViewById(R.id.taskDescription8);
        taskTitle8.setText("Task 8: Music Practice");
        taskDescription8.setText("Practice piano scales for 30 minutes.");
    }
}
