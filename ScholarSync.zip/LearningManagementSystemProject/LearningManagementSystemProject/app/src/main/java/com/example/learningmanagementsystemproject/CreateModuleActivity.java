package com.example.learningmanagementsystemproject;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

public class CreateModuleActivity extends AppCompatActivity {

    private TextInputEditText etModuleName, etModuleCode, etModuleDescription;
    private MaterialButton btnCreateModule;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_module);

        etModuleName = findViewById(R.id.etModuleName);
        etModuleCode = findViewById(R.id.etModuleCode);
        etModuleDescription = findViewById(R.id.etModuleDescription);
        btnCreateModule = findViewById(R.id.btnCreateModule);

        btnCreateModule.setOnClickListener(v -> {
            String name = etModuleName.getText().toString().trim();
            String code = etModuleCode.getText().toString().trim();
            String desc = etModuleDescription.getText().toString().trim();

            if (validateInputs(name, code, desc)) {
                // TODO: handle module creation logic (save to database, API call, etc.)
                Toast.makeText(CreateModuleActivity.this, "Module Created Successfully!", Toast.LENGTH_SHORT).show();

                // Optionally clear inputs
                etModuleName.setText("");
                etModuleCode.setText("");
                etModuleDescription.setText("");
            }
        });
    }

    private boolean validateInputs(String name, String code, String desc) {
        if (TextUtils.isEmpty(name)) {
            etModuleName.setError("Module Name is required");
            return false;
        }
        if (TextUtils.isEmpty(code)) {
            etModuleCode.setError("Module Code is required");
            return false;
        }
        if (TextUtils.isEmpty(desc)) {
            etModuleDescription.setError("Description is required");
            return false;
        }
        return true;
    }
}
