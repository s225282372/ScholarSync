package com.example.learningmanagementsystemproject;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class CoursesActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private CourseAdapter courseAdapter;
    private List<String> courseList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_courses);

        Toolbar toolbar = findViewById(R.id.toolbar_courses);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Courses");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        recyclerView = findViewById(R.id.recycler_courses);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        courseList = new ArrayList<>();
        courseList.add("Web Development 101");
        courseList.add("Advanced Java Programming");
        courseList.add("UI/UX Design Principles");
        courseList.add("Database Management");
        courseList.add("Networking Fundamentals");

        courseAdapter = new CourseAdapter(courseList);
        recyclerView.setAdapter(courseAdapter);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish(); // go back when back arrow is clicked
        return true;
    }
}
