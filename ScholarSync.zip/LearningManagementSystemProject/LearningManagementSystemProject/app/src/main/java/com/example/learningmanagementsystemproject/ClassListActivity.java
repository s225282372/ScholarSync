package com.example.learningmanagementsystemproject;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;

public class ClassListActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_class_list);

        ListView listView = findViewById(R.id.classListView);
        String[] classNames = {
                "Angel Makhoba", "Sanele Mkhize", "Elizabeth Khumalo", "Sandile Mhongo", "Nontobeku Buthelezi", "Silindile Cele",
                "Themba Dlamini", "Nomcebo Zulu", "Lindokuhle Ngcobo", "Sipho Shabalala", "Ayanda Nxumalo", "Zinhle Ntuli",
                "Thabo Khumalo", "Lungile Mthembu", "Sbusiso Majozi", "Nosipho Mthethwa", "Andile Hlongwane", "Phindile Ndlovu",
                "Simphiwe Zondo", "Nomvula Mbatha", "Khethukuthula Buthelezi", "Samkelo Khuzwayo", "Precious Mlambo", "Njabulo Nene",
                "Gugulethu Cele", "Bongani Gumede", "Khanyisile Sithole", "Mthokozisi Ncube", "Sibongile Zuma", "Thokozani Zwane",
                "Mpumelelo Dube"
        };


        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                classNames
        );

        listView.setAdapter(adapter);
    }
}
