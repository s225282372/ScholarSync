package com.example.learningmanagementsystemproject;


import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import java.security.SecureRandom;

public class CreateInstructorActivity extends AppCompatActivity {

    private TextInputEditText etName, etEmail, etPhone, etPassword;
    private RadioGroup rgGender;
    private RadioButton rbMale, rbFemale;
    private MaterialButton btnGeneratePassword, btnSubmitInstructor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_instructor); // Change to your actual layout file name

        // Initialize views
        etName = findViewById(R.id.etStudentName);
        etEmail = findViewById(R.id.etStudentEmail);
        etPhone = findViewById(R.id.etStudentPhone);
        etPassword = findViewById(R.id.etStudentPassword);
        rgGender = findViewById(R.id.rgGender);
        rbMale = findViewById(R.id.rbMale);
        rbFemale = findViewById(R.id.rbFemale);
        btnGeneratePassword = findViewById(R.id.btnGeneratePassword);
        btnSubmitInstructor = findViewById(R.id.btnSubmitStudent); // Use same ID if reusing layout

        // Set up listeners
        btnGeneratePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String password = generateSecurePassword(10);
                etPassword.setText(password);
            }
        });

        btnSubmitInstructor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                submitInstructorData();
            }
        });
    }

    private void submitInstructorData() {
        String name = etName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        String gender = "";
        int selectedId = rgGender.getCheckedRadioButtonId();
        if (selectedId == R.id.rbMale) {
            gender = "Male";
        } else if (selectedId == R.id.rbFemale) {
            gender = "Female";
        }

        // Validate
        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(email) || TextUtils.isEmpty(phone)
                || TextUtils.isEmpty(password) || TextUtils.isEmpty(gender)) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Example of successful data capture
        Toast.makeText(this, "Instructor Created:\n" +
                "Name: " + name + "\nEmail: " + email +
                "\nPhone: " + phone + "\nGender: " + gender, Toast.LENGTH_LONG).show();

        // TODO: Save instructor to database or send to server here
    }

    private String generateSecurePassword(int length) {
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#$%!";
        SecureRandom random = new SecureRandom();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            sb.append(chars.charAt(random.nextInt(chars.length())));
        }
        return sb.toString();
    }
}
