package com.example.learningmanagementsystemproject;

import android.graphics.Paint;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;

public class CourseDetailActivity extends AppCompatActivity {

    private TextView courseCodeTextView, courseTitleTextView;
    private RecyclerView tasksRecyclerView;
    private MaterialButton markCompletedButton;

    private List<Task> taskList;
    private TaskAdapter taskAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_detail);

        courseCodeTextView = findViewById(R.id.course_code);
        courseTitleTextView = findViewById(R.id.course_title);
        tasksRecyclerView = findViewById(R.id.tasks_recycler_view);
        markCompletedButton = findViewById(R.id.btn_mark_completed);

        // Dummy course data, ideally this comes from Intent extras or ViewModel
        courseCodeTextView.setText("CS101");
        courseTitleTextView.setText("Introduction to Computer Science");

        taskList = new ArrayList<>();
        taskList.add(new Task("Complete Chapter 1 exercises"));
        taskList.add(new Task("Submit Assignment 1"));
        taskList.add(new Task("Participate in discussion forum"));

        taskAdapter = new TaskAdapter(taskList, (position, isChecked) -> {
            Task task = taskList.get(position);
            task.setCompleted(isChecked);
            taskAdapter.notifyItemChanged(position);
        });

        tasksRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        tasksRecyclerView.setAdapter(taskAdapter);

        markCompletedButton.setOnClickListener(v -> {
            for (Task task : taskList) {
                task.setCompleted(true);
            }
            taskAdapter.notifyDataSetChanged();
            markCompletedButton.setEnabled(false);
            markCompletedButton.setText("All Tasks Completed ✓");
        });
    }
}

