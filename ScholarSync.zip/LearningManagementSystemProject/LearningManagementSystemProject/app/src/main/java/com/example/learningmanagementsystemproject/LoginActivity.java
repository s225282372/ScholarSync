package com.example.learningmanagementsystemproject;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText usernameInput, passwordInput;
    private Button loginButton;
    private RadioGroup roleRadioGroup;
    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        usernameInput = findViewById(R.id.username);
        passwordInput = findViewById(R.id.password);
        loginButton = findViewById(R.id.loginButton);
        roleRadioGroup = findViewById(R.id.roleRadioGroup);
        db = new DatabaseHelper(this);

        loginButton.setOnClickListener(v -> {
            String username = usernameInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();

            // Basic validation
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Username and password cannot be empty.", Toast.LENGTH_SHORT).show();
                return;
            }

            int selectedRoleId = roleRadioGroup.getCheckedRadioButtonId();
            if (selectedRoleId == -1) {
                Toast.makeText(this, "Please select a role.", Toast.LENGTH_SHORT).show();
                return;
            }

            RadioButton selectedRadioButton = findViewById(selectedRoleId);
            String selectedRole = selectedRadioButton.getText().toString().toLowerCase();

            // Check credentials in database
            boolean validLogin = db.checkUserRole(username, password, selectedRole);

            if (validLogin) {
                // Navigate based on role
                Intent intent;
                switch (selectedRole) {
                    case "admin":
                        intent = new Intent(this, AdminNavigationActivity.class);
                        break;
                    case "instructor":
                        intent = new Intent(this, InstructorNavigationActivity.class);
                        break;
                    case "student":
                        intent = new Intent(this, StudentDashboardActivity.class);
                        break;
                    default:
                        Toast.makeText(this, "Unknown role selected.", Toast.LENGTH_SHORT).show();
                        return;
                }
                // Clear back stack and start new activity
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(this, "Invalid username, password or role.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
