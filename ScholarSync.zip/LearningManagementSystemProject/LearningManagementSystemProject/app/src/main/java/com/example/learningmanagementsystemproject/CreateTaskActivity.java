package com.example.learningmanagementsystemproject;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class CreateTaskActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_task);

        EditText editTitle = findViewById(R.id.editTaskTitle);
        EditText editDescription = findViewById(R.id.editTaskDescription);
        Button createBtn = findViewById(R.id.createTaskButton);

        createBtn.setOnClickListener(v -> {
            String title = editTitle.getText().toString();
            String description = editDescription.getText().toString();

            if (title.isEmpty() || description.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            } else {
                // Normally save to DB here
                Toast.makeText(this, "Task Created: " + title, Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }
}
