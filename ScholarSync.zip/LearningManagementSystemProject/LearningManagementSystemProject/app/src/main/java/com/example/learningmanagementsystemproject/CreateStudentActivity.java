package com.example.learningmanagementsystemproject;

import android.os.Bundle;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.Editable;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.security.SecureRandom;

public class CreateStudentActivity extends AppCompatActivity {

    private TextInputEditText etStudentName, etStudentEmail, etStudentPhone, etStudentPassword;
    private TextInputLayout tilStudentName, tilStudentEmail, tilStudentPhone, tilStudentPassword;
    private RadioGroup rgGender;
    private MaterialButton btnGeneratePassword, btnSubmitStudent;

    private static final String PASSWORD_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#$%!";
    private static final int PASSWORD_LENGTH = 10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_student);

        // Initialize TextInputLayouts (for error display)
        tilStudentName = findViewById(R.id.tilStudentName);
        tilStudentEmail = findViewById(R.id.tilStudentEmail);
        tilStudentPhone = findViewById(R.id.tilStudentPhone);
        tilStudentPassword = findViewById(R.id.tilStudentPassword);

        // Initialize TextInputEditTexts
        etStudentName = findViewById(R.id.etStudentName);
        etStudentEmail = findViewById(R.id.etStudentEmail);
        etStudentPhone = findViewById(R.id.etStudentPhone);
        etStudentPassword = findViewById(R.id.etStudentPassword);

        rgGender = findViewById(R.id.rgGender);
        btnGeneratePassword = findViewById(R.id.btnGeneratePassword);
        btnSubmitStudent = findViewById(R.id.btnSubmitStudent);

        btnGeneratePassword.setOnClickListener(view -> {
            String generatedPassword = generateRandomPassword(PASSWORD_LENGTH);
            etStudentPassword.setText(generatedPassword);
            Toast.makeText(this, "Random password generated", Toast.LENGTH_SHORT).show();
        });

        btnSubmitStudent.setOnClickListener(view -> submitStudentData());

        // Optional: Clear errors as user types
        setupErrorClearingOnTyping();
    }

    private void setupErrorClearingOnTyping() {
        TextWatcher clearErrorWatcher = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                clearAllErrors();
            }
            @Override public void afterTextChanged(Editable s) {}
        };

        etStudentName.addTextChangedListener(clearErrorWatcher);
        etStudentEmail.addTextChangedListener(clearErrorWatcher);
        etStudentPhone.addTextChangedListener(clearErrorWatcher);
        etStudentPassword.addTextChangedListener(clearErrorWatcher);
    }

    private void clearAllErrors() {
        tilStudentName.setError(null);
        tilStudentEmail.setError(null);
        tilStudentPhone.setError(null);
        tilStudentPassword.setError(null);
    }

    private void submitStudentData() {
        clearAllErrors();

        String name = etStudentName.getText().toString().trim();
        String email = etStudentEmail.getText().toString().trim();
        String phone = etStudentPhone.getText().toString().trim();
        String password = etStudentPassword.getText().toString().trim();

        int selectedGenderId = rgGender.getCheckedRadioButtonId();
        RadioButton selectedGenderButton = selectedGenderId != -1 ? findViewById(selectedGenderId) : null;
        String gender = selectedGenderButton != null ? selectedGenderButton.getText().toString() : "";

        boolean isValid = true;

        if (TextUtils.isEmpty(name)) {
            tilStudentName.setError("Name is required");
            isValid = false;
        }

        if (TextUtils.isEmpty(email)) {
            tilStudentEmail.setError("Email is required");
            isValid = false;
        } else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            tilStudentEmail.setError("Invalid email format");
            isValid = false;
        }

        if (TextUtils.isEmpty(phone)) {
            tilStudentPhone.setError("Phone number is required");
            isValid = false;
        } else if (!phone.matches("\\d{10}")) {
            tilStudentPhone.setError("Phone must be 10 digits");
            isValid = false;
        }

        if (TextUtils.isEmpty(password)) {
            tilStudentPassword.setError("Password is required");
            isValid = false;
        } else {
            if (password.length() < 8) {
                tilStudentPassword.setError("At least 8 characters");
                isValid = false;
            }
            if (!password.matches(".*\\d.*")) {
                tilStudentPassword.setError("Must include at least one number");
                isValid = false;
            }
            if (!password.matches(".*[@#$%!].*")) {
                tilStudentPassword.setError("Must include a special char (@#$%!)");
                isValid = false;
            }
        }

        if (selectedGenderId == -1) {
            Toast.makeText(this, "Please select a gender", Toast.LENGTH_LONG).show();
            isValid = false;
        }

        if (!isValid) return;

        // All validations passed - you can handle backend logic here

        Toast.makeText(this, "Student Created:\n" + name + " | " + email + " | " + phone + " | " + gender, Toast.LENGTH_LONG).show();

        clearFormFields();
    }

    private String generateRandomPassword(int length) {
        SecureRandom rnd = new SecureRandom();
        StringBuilder password = new StringBuilder();

        while (password.length() < length) {
            int index = rnd.nextInt(PASSWORD_CHARS.length());
            password.append(PASSWORD_CHARS.charAt(index));
        }
        return password.toString();
    }

    private void clearFormFields() {
        etStudentName.setText("");
        etStudentEmail.setText("");
        etStudentPhone.setText("");
        etStudentPassword.setText("");
        rgGender.clearCheck();
        clearAllErrors();
    }
}
